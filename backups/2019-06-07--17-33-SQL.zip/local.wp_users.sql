/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"fastfireadmin","$P$BPPxbuIHKrBw7uCqD/mdwOWvIL4PHP1","fastfireadmin","dev@fastfire.com","","2019-06-07 19:00:33","",0,"fastfireadmin");
