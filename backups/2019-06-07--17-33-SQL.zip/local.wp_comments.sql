/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_comments` VALUES
(1,1,"A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2019-06-07 19:00:33","2019-06-07 19:00:33","Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.",0,"1","","",0,0);
